<?php
include("cookiescheck.php");
?>
<noscript>
    <div id="containertop">
        <h3 style="color:grey;">For a better experience on Auctions, enable JavaScript in your browser</h3>
        </div>
</noscript>
<div id="header" style="text-align: center;">
      <img src="title.png" style="height:50px;  "></img>
</div>    